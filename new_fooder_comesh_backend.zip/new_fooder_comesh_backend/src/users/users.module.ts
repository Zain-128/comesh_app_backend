import { Module, forwardRef } from '@nestjs/common';
import { UsersService } from './users.service';
import { UsersController } from './users.controller';
import { UserSchema } from './user.schema';
import { MongooseModule } from '@nestjs/mongoose';
import { ConfigModule } from '@nestjs/config';
import { UserDevicesModule } from 'src/user-devices/user-devices.module';
import { NotificationsModule } from 'src/notifications/notifications.module';
import { TwilioModule } from '../providers/twilio/twilio.module';
import { MessagingModule } from 'src/fcm/fcm.module';
import { SendgridService } from 'src/sendgrid/sendgrid.service';
import { MediaModule } from 'src/media/media.module';
import { ChatsModule } from 'src/chats/chats.module';
import { ProfileMediaProcessorService } from './profile-media.processor';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'User', schema: UserSchema }]),
    NotificationsModule,
    UserDevicesModule,
    TwilioModule,
    MessagingModule,
    ConfigModule,
    MediaModule,
    forwardRef(() => ChatsModule),
  ],
  exports: [MongooseModule.forFeature([{ name: 'User', schema: UserSchema }])],
  providers: [UsersService, SendgridService, ProfileMediaProcessorService],
  controllers: [UsersController],
})
export class UsersModule {}
